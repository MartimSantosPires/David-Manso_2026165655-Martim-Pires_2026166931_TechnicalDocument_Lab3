using UnityEngine;

[CreateAssetMenu(fileName = "PlayerStats", menuName = "Player Stats")]
public class PlayerStats : ScriptableObject 
{
    [Header("Config")]

    [SerializeField] public float chLvl;

    [Header("Health")]

    [SerializeField] public float health;

    [SerializeField] public float Maxhealth;

}
