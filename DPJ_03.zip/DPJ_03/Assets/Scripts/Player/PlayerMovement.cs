using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    [Header("Config")]
    [SerializeField] private float speed;

    private Vector2 moveDirection;

    private Action actions;

    private Rigidbody2D rb;

    private PlayerAnimations playerAnimations;


    private Player player;

    private void Update()
    {
        ReadMovement();
    }

    private void Awake()
    {
        actions = new Action();
        rb = GetComponent<Rigidbody2D>();
        playerAnimations = GetComponent<PlayerAnimations>();


        player = GetComponent<Player>();
    }

    private void OnEnable()
    {
        actions.Movement.Enable();
    }

    private void OnDisable()
    {
        actions.Movement.Disable();
    }

    private void ReadMovement()
    {
        moveDirection = actions.Movement.Move.ReadValue<Vector2>().normalized;

        if (moveDirection == Vector2.zero)
        {
            playerAnimations.SetMoveBoolTransition(false);
            return;
        }

        playerAnimations.SetMoveBoolTransition(true);
        playerAnimations.SetMoveAnimation(moveDirection);
    }

    private void Move()
    {
        
        if (player.Stats.health <= 0)
        {
            return; 
        }

        rb.MovePosition(rb.position + moveDirection * (speed * Time.fixedDeltaTime));
    }

    private void FixedUpdate()
    {
        Move();
    }
}