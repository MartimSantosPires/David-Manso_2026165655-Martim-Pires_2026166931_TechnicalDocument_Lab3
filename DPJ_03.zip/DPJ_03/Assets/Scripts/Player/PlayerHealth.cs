using System.Runtime.InteropServices.WindowsRuntime;
using UnityEditor.Search;
using UnityEditor.VersionControl;
using UnityEngine;

public class PlayerHealth : MonoBehaviour, IDamageable
{

    [SerializeField] private PlayerStats PlayerStats;

    
    private PlayerAnimations playerAnimations;

    private void Awake()
    {
        
        playerAnimations = GetComponent<PlayerAnimations>();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            TakeDamage(1f);
        }

    }

    //Criamos a interface IDamageable em que o m�todo � o TakeDamage e que o valor � o float amount.
    //O m�todo encontra-se acess�vel ap�s termos implementado a interface dentro da class "PlayerHealth"
    public void TakeDamage(float amount)
    {
        PlayerStats.health -= amount;

        if (PlayerStats.health <= 0)
        {
            PlayerDead();
        }
    }

    private void PlayerDead()
    {
        Debug.Log("Jogador Derrotado");

        
        playerAnimations.SetDeadAnimation(true);
    }

}