using UnityEngine;

public class PlayerAnimations : MonoBehaviour 
{
    private readonly int MoveX = Animator.StringToHash("MoveX");
    private readonly int MoveY = Animator.StringToHash("MoveY");
    private readonly int moving = Animator.StringToHash("Moving");
    private readonly int ded = Animator.StringToHash("Dead");

    private Animator animator;

    private void Update()
    {
        animator = GetComponent<Animator>();
    }

    public void SetDeadAnimation (bool dead)
    {
        animator.SetTrigger(ded);
    }

    public void SetMoveBoolTransition(bool value)
    {
        animator.SetBool(moving, value);
    }

    public void SetMoveAnimation(Vector2 dir)
    {
        animator.SetFloat(MoveX, dir.x);
        animator.SetFloat(MoveY, dir.y);
    }

}